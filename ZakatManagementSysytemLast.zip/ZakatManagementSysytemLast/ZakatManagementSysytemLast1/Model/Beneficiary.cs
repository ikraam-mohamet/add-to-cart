﻿namespace ZakatManagementSysytemLast.Model
{
    public class Beneficiary
    {
        public int BeneficiaryID { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    
}
}
