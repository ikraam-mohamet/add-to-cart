﻿namespace ZakatManagementSysytemLast.Model
{
    public class Donors
    {
        public int DonorID { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    
}
}
