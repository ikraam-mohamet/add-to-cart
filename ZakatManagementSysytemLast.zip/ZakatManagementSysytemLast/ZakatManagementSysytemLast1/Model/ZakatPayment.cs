﻿namespace ZakatManagementSysytemLast.Model
{
    public class ZakatPayment
    {
        public int PaymentID { get; set; }
        public int DonorID { get; set; }
        public int BeneficiaryID { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
    }
}
