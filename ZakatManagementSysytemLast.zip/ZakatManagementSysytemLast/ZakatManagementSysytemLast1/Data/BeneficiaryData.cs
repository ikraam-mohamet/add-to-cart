﻿using Microsoft.Data.SqlClient;
using System.Data;
using ZakatManagementSysytemLast.Model;

namespace ZakatManagementSysytemLast.Data
{
    public class BeneficiaryData
    {
        string conStr = "Server=DESKTOP-N64CJAK\\SERVER;Database=ZakatDB;Trusted_Connection=True;TrustServerCertificate=True";

        // GET ALL
        public List<Beneficiary> GetAllBeneficiaries()
        {
            List<Beneficiary> beneficiaries = new List<Beneficiary>();

            SqlConnection con = new SqlConnection(conStr);

            string query = "SELECT * FROM Beneficiaries";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Beneficiary b = new Beneficiary();

                b.BeneficiaryID = Convert.ToInt32(dr["BeneficiaryID"]);
                b.FullName = dr["FullName"].ToString();
                b.Phone = dr["Phone"].ToString();
                b.Address = dr["Address"].ToString();

                beneficiaries.Add(b);
            }

            con.Close();

            return beneficiaries;
        }

        // GET BY ID (FIXED -> returns null if not found)
        public Beneficiary GetBeneficiaryById(int id)
        {
            Beneficiary beneficiary = null;

            SqlConnection con = new SqlConnection(conStr);

            string query = "SELECT * FROM Beneficiaries WHERE BeneficiaryID=@BeneficiaryID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@BeneficiaryID", id);

            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                beneficiary = new Beneficiary();

                beneficiary.BeneficiaryID = Convert.ToInt32(dr["BeneficiaryID"]);
                beneficiary.FullName = dr["FullName"].ToString();
                beneficiary.Phone = dr["Phone"].ToString();
                beneficiary.Address = dr["Address"].ToString();
            }

            con.Close();

            return beneficiary;
        }

        // INSERT
        public void AddBeneficiary(Beneficiary b)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = @"INSERT INTO Beneficiaries
                            (FullName, Phone, Address)
                            VALUES
                            (@FullName, @Phone, @Address)";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@FullName", b.FullName);
            cmd.Parameters.AddWithValue("@Phone", b.Phone);
            cmd.Parameters.AddWithValue("@Address", b.Address);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        // UPDATE
        public void UpdateBeneficiary(Beneficiary b)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = @"UPDATE Beneficiaries
                             SET FullName=@FullName,
                                 Phone=@Phone,
                                 Address=@Address
                             WHERE BeneficiaryID=@BeneficiaryID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@BeneficiaryID", b.BeneficiaryID);
            cmd.Parameters.AddWithValue("@FullName", b.FullName);
            cmd.Parameters.AddWithValue("@Phone", b.Phone);
            cmd.Parameters.AddWithValue("@Address", b.Address);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        // DELETE
        public void DeleteBeneficiary(int id)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = "DELETE FROM Beneficiaries WHERE BeneficiaryID=@BeneficiaryID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@BeneficiaryID", id);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public List<Beneficiary> SearchBeneficiaries(string name)
        {
            List<Beneficiary> dataList = new List<Beneficiary>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "SELECT * FROM Beneficiaries WHERE FullName LIKE @name";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@name", "%" + name + "%");

                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    dataList.Add(new Beneficiary
                    {
                        BeneficiaryID = Convert.ToInt32(dr["BeneficiaryID"]),
                        FullName = dr["FullName"].ToString(),
                        Phone = dr["Phone"].ToString(),
                        Address = dr["Address"].ToString()
                    });
                }

                con.Close();
            }

            return dataList;
        }


    }
}