﻿using Microsoft.Data.SqlClient;
using ZakatManagementSysytemLast.Model;

namespace ZakatManagementSysytemLast.Data
{
    public class ZakatPaymentData
    {
        string conStr = "Server=DESKTOP-N64CJAK\\SERVER;Database=ZakatDB;Trusted_Connection=True;TrustServerCertificate=True";

        // GET ALL
        public List<ZakatPayment> GetAllZakatPayment()
        {
            List<ZakatPayment> payments = new List<ZakatPayment>();

            SqlConnection con = new SqlConnection(conStr);

            string query = "SELECT * FROM ZakatPayments";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ZakatPayment payment = new ZakatPayment();

                payment.PaymentID = Convert.ToInt32(dr["PaymentID"]);
                payment.DonorID = Convert.ToInt32(dr["DonorID"]);
                payment.BeneficiaryID = Convert.ToInt32(dr["BeneficiaryID"]);
                payment.Amount = Convert.ToDecimal(dr["Amount"]);
                payment.PaymentDate = Convert.ToDateTime(dr["PaymentDate"]);

                payments.Add(payment);
            }

            con.Close();

            return payments;
        }

        // GET BY ID
        public ZakatPayment? GetPaymentById(int id)
        {
            ZakatPayment? payment = null;

            SqlConnection con = new SqlConnection(conStr);

            string query = "SELECT * FROM ZakatPayments WHERE PaymentID=@PaymentID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@PaymentID", id);

            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                payment = new ZakatPayment();

                payment.PaymentID = Convert.ToInt32(dr["PaymentID"]);
                payment.DonorID = Convert.ToInt32(dr["DonorID"]);
                payment.BeneficiaryID = Convert.ToInt32(dr["BeneficiaryID"]);
                payment.Amount = Convert.ToDecimal(dr["Amount"]);
                payment.PaymentDate = Convert.ToDateTime(dr["PaymentDate"]);
            }

            con.Close();

            return payment;
        }

        // INSERT
        public void AddPayment(ZakatPayment p)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = @"INSERT INTO ZakatPayments
                            (DonorID, BeneficiaryID, Amount, PaymentDate)
                            VALUES
                            (@DonorID, @BeneficiaryID, @Amount, @PaymentDate)";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@DonorID", p.DonorID);
            cmd.Parameters.AddWithValue("@BeneficiaryID", p.BeneficiaryID);
            cmd.Parameters.AddWithValue("@Amount", p.Amount);
            cmd.Parameters.AddWithValue("@PaymentDate", p.PaymentDate);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        // UPDATE
        public void UpdatePayment(ZakatPayment p)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = @"UPDATE ZakatPayments
                             SET DonorID=@DonorID,
                                 BeneficiaryID=@BeneficiaryID,
                                 Amount=@Amount,
                                 PaymentDate=@PaymentDate
                             WHERE PaymentID=@PaymentID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@PaymentID", p.PaymentID);
            cmd.Parameters.AddWithValue("@DonorID", p.DonorID);
            cmd.Parameters.AddWithValue("@BeneficiaryID", p.BeneficiaryID);
            cmd.Parameters.AddWithValue("@Amount", p.Amount);
            cmd.Parameters.AddWithValue("@PaymentDate", p.PaymentDate);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        // DELETE
        public void DeletePayment(int id)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = "DELETE FROM ZakatPayments WHERE PaymentID=@PaymentID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@PaymentID", id);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }





    }
}