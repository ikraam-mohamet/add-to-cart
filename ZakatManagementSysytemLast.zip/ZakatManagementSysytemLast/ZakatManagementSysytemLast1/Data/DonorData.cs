﻿using Microsoft.Data.SqlClient;
using ZakatManagementSysytemLast.Model;

namespace ZakatManagementSysytemLast.Data
{
    public class DonorData
    {
        string conStr = "Server=DESKTOP-N64CJAK\\SERVER;Database=ZakatDB;Trusted_Connection=True;TrustServerCertificate=True";

        // GET ALL
        public List<Donors> GetAllDonors()
        {
            List<Donors> donors = new List<Donors>();

            SqlConnection con = new SqlConnection(conStr);
            string query = "SELECT * FROM Donors";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Donors d = new Donors();

                d.DonorID = Convert.ToInt32(dr["DonorID"]);
                d.FullName = dr["FullName"].ToString();
                d.Phone = dr["Phone"].ToString();
                d.Address = dr["Address"].ToString();

                donors.Add(d);
            }

            con.Close();

            return donors;
        }

        // GET BY ID
        public Donors? GetDonorById(int id)
        {
            Donors? donor = null;

            SqlConnection con = new SqlConnection(conStr);

            string query = "SELECT * FROM Donors WHERE DonorID=@DonorID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@DonorID", id);

            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                donor = new Donors();

                donor.DonorID = Convert.ToInt32(dr["DonorID"]);
                donor.FullName = dr["FullName"].ToString();
                donor.Phone = dr["Phone"].ToString();
                donor.Address = dr["Address"].ToString();
            }

            con.Close();

            return donor;
        }

        // INSERT
        public void AddDonor(Donors d)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = @"INSERT INTO Donors
                            (FullName,Phone,Address)
                            VALUES
                            (@FullName,@Phone,@Address)";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@FullName", d.FullName);
            cmd.Parameters.AddWithValue("@Phone", d.Phone);
            cmd.Parameters.AddWithValue("@Address", d.Address);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        // UPDATE
        public void UpdateDonor(Donors d)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = @"UPDATE Donors
                             SET FullName=@FullName,
                                 Phone=@Phone,
                                 Address=@Address
                             WHERE DonorID=@DonorID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@DonorID", d.DonorID);
            cmd.Parameters.AddWithValue("@FullName", d.FullName);
            cmd.Parameters.AddWithValue("@Phone", d.Phone);
            cmd.Parameters.AddWithValue("@Address", d.Address);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        // DELETE
        public void DeleteDonor(int id)
        {
            SqlConnection con = new SqlConnection(conStr);

            string query = "DELETE FROM Donors WHERE DonorID=@DonorID";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@DonorID", id);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}