﻿using Microsoft.Data.SqlClient;
using ZakatManagementSysytemLast.Model;

namespace ZakatManagementSysytemLast.Data
{
    public class UserData
    {
       // string conStr = "Server=.;Database=ZakatDB;Trusted_Connection=True;TrustServerCertificate=True;";


        string conStr = "Server=DESKTOP-N64CJAK\\SERVER;Database=ZakatDB;Trusted_Connection=True;TrustServerCertificate=True";

        // ================= REGISTER =================
        public void RegisterUser(Users u)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = @"INSERT INTO Users (Username, Password, Role)
                                 VALUES (@Username, @Password, @Role)";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Username", u.Username);
                    cmd.Parameters.AddWithValue("@Password", u.Password);

                    // haddii role aan la dirin → default user
                    cmd.Parameters.AddWithValue("@Role", u.Role ?? "user");

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // ================= LOGIN =================
        public Users Login(string username, string password)
        {
            Users user = null;

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = @"SELECT * FROM Users 
                                 WHERE Username=@Username AND Password=@Password";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    con.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            user = new Users
                            {
                                Id = Convert.ToInt32(dr["Id"]),
                                Username = dr["Username"].ToString(),
                                Password = dr["Password"].ToString(),
                                Role = dr["Role"].ToString()
                            };
                        }
                    }
                }
            }

            return user;
        }

        // ================= GET ALL USERS =================
        public List<Users> GetAllUsers()
        {
            List<Users> list = new List<Users>();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "SELECT * FROM Users";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            list.Add(new Users
                            {
                                Id = Convert.ToInt32(dr["Id"]),
                                Username = dr["Username"].ToString(),
                                Password = dr["Password"].ToString(),
                                Role = dr["Role"].ToString()
                            });
                        }
                    }
                }
            }

            return list;
        }

        // ================= DELETE USER =================
        public void DeleteUser(int id)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "DELETE FROM Users WHERE Id=@Id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}