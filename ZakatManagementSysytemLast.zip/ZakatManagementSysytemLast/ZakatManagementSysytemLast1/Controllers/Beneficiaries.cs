﻿using Microsoft.AspNetCore.Mvc;
using ZakatManagementSysytemLast.Data;
using ZakatManagementSysytemLast.Model;

namespace ZakatManagementSysytemLast.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BeneficiaryController : ControllerBase
    {
        BeneficiaryData data = new BeneficiaryData();

        // GET ALL
        [HttpGet]
        public IActionResult GetAllBeneficiaries()
        {
            return Ok(data.GetAllBeneficiaries());
        }

        // GET BY ID
        [HttpGet("{id}")]
        public IActionResult GetBeneficiaryById(int id)
        {
            var beneficiary = data.GetBeneficiaryById(id);

            if (beneficiary == null)
            {
                return NotFound("Beneficiary ID not found");
            }

            return Ok(beneficiary);
        }

        // INSERT
        [HttpPost]
        public IActionResult AddBeneficiary(Beneficiary beneficiary)
        {
            data.AddBeneficiary(beneficiary);

            return Ok("Beneficiary Added Successfully");
        }

        // UPDATE
        [HttpPut]
        public IActionResult UpdateBeneficiary(Beneficiary beneficiary)
        {
            var existingBeneficiary =
                data.GetBeneficiaryById(beneficiary.BeneficiaryID);

            if (existingBeneficiary == null)
            {
                return NotFound("Beneficiary ID not found");
            }

            data.UpdateBeneficiary(beneficiary);

            return Ok("Beneficiary Updated Successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteBeneficiary(int id)
        {
            var beneficiary = data.GetBeneficiaryById(id);

            if (beneficiary == null)
            {
                return NotFound("Beneficiary ID not found");
            }

            data.DeleteBeneficiary(id);

            return Ok("Beneficiary Deleted Successfully");
        }

        [HttpGet("search")]
        public IActionResult Search(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return BadRequest("Name is required");
            }

            var result = data.SearchBeneficiaries(name);

            if (result == null || result.Count == 0)
            {
                return NotFound("No Beneficiaries found");
            }

            return Ok(result);
        }


    }
}