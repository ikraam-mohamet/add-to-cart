﻿using Microsoft.AspNetCore.Mvc;
using ZakatManagementSysytemLast.Data;
using ZakatManagementSysytemLast.Model;

namespace ZakatManagementSysytemLast.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ZakatPaymentController : ControllerBase
    {
        ZakatPaymentData data = new ZakatPaymentData();
        DonorData donorData = new DonorData();
        BeneficiaryData beneficiaryData = new BeneficiaryData();

        [HttpGet]
        public IActionResult GetAllPayments()
        {
            return Ok(data.GetAllZakatPayment());
        }

        [HttpGet("{id}")]
        public IActionResult GetPaymentById(int id)
        {
            var payment = data.GetPaymentById(id);

            if (payment == null)
            {
                return NotFound("Payment ID not found");
            }

            return Ok(payment);
        }

        [HttpPost]
        public IActionResult AddPayment(ZakatPayment payment)
        {
            var donor = donorData.GetDonorById(payment.DonorID);

            if (donor == null)
            {
                return NotFound("Donor ID not found");
            }

            var beneficiary = beneficiaryData.GetBeneficiaryById(payment.BeneficiaryID);

            if (beneficiary == null)
            {
                return NotFound("Beneficiary ID not found");
            }

            data.AddPayment(payment);

            return Ok("Payment Added Successfully");
        }

        [HttpPut]
        public IActionResult UpdatePayment(ZakatPayment payment)
        {
            var existingPayment = data.GetPaymentById(payment.PaymentID);

            if (existingPayment == null)
            {
                return NotFound("Payment ID not found");
            }

            var donor = donorData.GetDonorById(payment.DonorID);

            if (donor == null)
            {
                return NotFound("Donor ID not found");
            }

            var beneficiary = beneficiaryData.GetBeneficiaryById(payment.BeneficiaryID);

            if (beneficiary == null)
            {
                return NotFound("Beneficiary ID not found");
            }

            data.UpdatePayment(payment);

            return Ok("Payment Updated Successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePayment(int id)
        {
            var payment = data.GetPaymentById(id);

            if (payment == null)
            {
                return NotFound("Payment ID not found");
            }

            data.DeletePayment(id);

            return Ok("Payment Deleted Successfully");
        }
    }
}