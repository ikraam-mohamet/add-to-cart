﻿using Microsoft.AspNetCore.Mvc;
using ZakatManagementSysytemLast.Data;
using ZakatManagementSysytemLast.Model;

namespace ZakatManagementSysytemLast.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DonorController : ControllerBase
    {
        DonorData data = new DonorData();

        [HttpGet]
        public IActionResult GetAllDonors()
        {
            return Ok(data.GetAllDonors());
        }

        [HttpGet("{id}")]
        public IActionResult GetDonorById(int id)
        {
            var donor = data.GetDonorById(id);

            if (donor == null)
            {
                return NotFound("Donor ID not found");
            }

            return Ok(donor);
        }

        [HttpPost]
        public IActionResult AddDonor(Donors donor)
        {
            data.AddDonor(donor);
            return Ok("Donor Added Successfully");
        }

        [HttpPut]
        public IActionResult UpdateDonor(Donors donor)
        {
            var existingDonor = data.GetDonorById(donor.DonorID);

            if (existingDonor == null)
            {
                return NotFound("Donor ID not found");
            }

            data.UpdateDonor(donor);
            return Ok("Donor Updated Successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteDonor(int id)
        {
            var donor = data.GetDonorById(id);

            if (donor == null)
            {
                return NotFound("Donor ID not found");
            }

            data.DeleteDonor(id);
            return Ok("Donor Deleted Successfully");
        }
    }
}