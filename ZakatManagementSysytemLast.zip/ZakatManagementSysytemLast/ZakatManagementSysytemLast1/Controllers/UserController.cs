﻿using Microsoft.AspNetCore.Mvc;
using ZakatManagementSysytemLast.Data;
using ZakatManagementSysytemLast.Model;

namespace ZakatManagementSysytemLast.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        UserData data = new UserData();

        // ================= GET ALL USERS =================
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(data.GetAllUsers());
        }

        // ================= GET BY ID =================
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var user = data.GetAllUsers().Find(x => x.Id == id);

            if (user == null)
                return NotFound("User not found");

            return Ok(user);
        }

        // ================= REGISTER =================
        [HttpPost("register")]
        public IActionResult Register(Users user)
        {
            if (string.IsNullOrEmpty(user.Username) || string.IsNullOrEmpty(user.Password))
                return BadRequest("Username and Password are required");

            data.RegisterUser(user);
            return Ok("User registered successfully");
        }

        // ================= LOGIN =================
        [HttpPost("login")]
        public IActionResult Login(Users user)
        {
            var result = data.Login(user.Username, user.Password);

            if (result == null)
                return Unauthorized("Invalid username or password");

            return Ok(new
            {
                message = "Login successful",
                user = result
            });
        }

        // ================= DELETE =================
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var user = data.GetAllUsers().Find(x => x.Id == id);

            if (user == null)
                return NotFound("User not found");

            data.DeleteUser(id);

            return Ok("User deleted successfully");
        }
    }
}