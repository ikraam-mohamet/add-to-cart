

import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

/* ================= PAGES ================= */
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";

import Donor from "./pages/Donor";
import Beneficiaries from "./pages/Beneficiaries";
import Payment from "./pages/Payment";
import Reports from "./pages/Reports";
import About from "./pages/About";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Notifications from "./pages/Notifications";
import Users from "./pages/Users";

/* ================= COMPONENTS ================= */
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";

/* ================= LAYOUT ================= */
function Layout({
  notifications,
  setNotifications,
  darkMode,
  setDarkMode,
}) {
  return (
    <div
      className={
        darkMode
          ? "bg-black text-white min-h-screen flex"
          : "bg-gray-100 text-black min-h-screen flex"
      }
    >
      <Sidebar />

      <div className="flex-1 flex flex-col">
        <Navbar notifications={notifications} />

        <div className="p-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />

            <Route path="/donor" element={<Donor />} />
            <Route path="/beneficiaries" element={<Beneficiaries />} />
            <Route path="/payment" element={<Payment />} />
            <Route path="/users" element={<Users />} />

            <Route path="/reports" element={<Reports />} />
            <Route path="/about" element={<About />} />
            <Route path="/profile" element={<Profile />} />

            <Route
              path="/settings"
              element={
                <Settings
                  darkMode={darkMode}
                  setDarkMode={setDarkMode}
                  notifications={notifications}
                  setNotifications={setNotifications}
                />
              }
            />

            <Route
              path="/notifications"
              element={
                <Notifications
                  notifications={notifications}
                  setNotifications={setNotifications}
                />
              }
            />

            <Route path="*" element={<Navigate to="/dashboard" />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}

/* ================= APP ================= */
function App() {
  const [isAuth, setIsAuth] = useState(
    localStorage.getItem("auth") === "true"
  );

  const [darkMode, setDarkMode] = useState(
    localStorage.getItem("darkMode") === "true"
  );

  const [notifications, setNotifications] = useState([
    "New donation received 💰",
    "System report ready 📊",
    "New user registered 👤",
  ]);

  useEffect(() => {
    localStorage.setItem("darkMode", darkMode);
  }, [darkMode]);

  return (
    <Routes>
      {/* Home */}
      <Route path="/" element={<Home />} />

      {/* Login */}
      <Route
        path="/login"
        element={<Login setIsAuth={setIsAuth} />}
      />

      {/* Protected Routes */}
      <Route
        path="/*"
        element={
          isAuth ? (
            <Layout
              notifications={notifications}
              setNotifications={setNotifications}
              darkMode={darkMode}
              setDarkMode={setDarkMode}
            />
          ) : (
            <Navigate to="/login" />
          )
        }
      />
    </Routes>
  );
}

export default App;