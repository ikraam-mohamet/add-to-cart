
import {
  FaHome,
  FaUsers,
  FaHandHoldingHeart,
  FaMoneyBillWave,
  FaChartBar,
  FaInfoCircle,
  FaCog,
  FaSignOutAlt,
} from "react-icons/fa";

import { NavLink, useNavigate } from "react-router-dom";

function Sidebar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("auth");
    localStorage.removeItem("user");
    navigate("/");
  };

  const linkStyle = ({ isActive }) =>
    `flex items-center gap-3 p-3 rounded-lg mt-2 transition-all ${
      isActive
        ? "bg-white text-[#0B3C5D] font-semibold"
        : "text-white hover:bg-blue-700"
    }`;

  return (
    <div className="w-64 min-h-screen bg-[#0B3C5D] text-white flex flex-col">

      {/* LOGO */}
      <div className="text-center py-8 border-b border-blue-800">
        <div className="w-16 h-16 bg-white rounded-full mx-auto flex items-center justify-center text-[#0B3C5D] text-3xl font-bold">
          🕌
        </div>

        <h2 className="mt-4 text-xl font-bold">Zakat System</h2>
        <p className="text-blue-200 text-sm">Admin Dashboard</p>
      </div>

      {/* MENU */}
      <div className="flex-1 mt-6 px-4">

        <NavLink to="/dashboard" className={linkStyle}>
          <FaHome />
          Dashboard
        </NavLink>

        <NavLink to="/donor" className={linkStyle}>
          <FaHandHoldingHeart />
          Donors
        </NavLink>

        <NavLink to="/beneficiaries" className={linkStyle}>
          <FaUsers />
          Beneficiaries
        </NavLink>

        <NavLink to="/payment" className={linkStyle}>
          <FaMoneyBillWave />
          Payments
        </NavLink>

        <NavLink to="/reports" className={linkStyle}>
          <FaChartBar />
          Reports
        </NavLink>

        <NavLink to="/about" className={linkStyle}>
          <FaInfoCircle />
          About
        </NavLink>

        <NavLink to="/settings" className={linkStyle}>
          <FaCog />
          Settings
        </NavLink>

      </div>

      {/* LOGOUT */}
      <div className="p-4 border-t border-blue-800">
        <div
          onClick={handleLogout}
          className="flex items-center gap-3 p-3 rounded-lg hover:bg-red-600 cursor-pointer"
        >
          <FaSignOutAlt />
          Logout
        </div>
      </div>

    </div>
  );
}

export default Sidebar;