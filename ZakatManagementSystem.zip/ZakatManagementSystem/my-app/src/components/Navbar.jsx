import { FaBell, FaUserCircle } from "react-icons/fa";
import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Navbar({ notifications = [] }) {
  const [open, setOpen] = useState(false);
  const adminRef = useRef(null);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("auth");
    navigate("/");
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (adminRef.current && !adminRef.current.contains(event.target)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="bg-white shadow-sm h-20 flex items-center justify-between px-8 relative">

      <h1 className="text-3xl font-bold text-green-800">
        Zakat Management System
      </h1>

      <div className="flex items-center gap-8 relative">

        <div className="text-gray-500">
          <p className="font-medium">25 May 2025</p>
          <p className="text-sm">11:30 AM</p>
        </div>

        <div
          className="relative cursor-pointer"
          onClick={() => navigate("/notifications")}
        >
          <FaBell className="text-2xl text-gray-600 hover:text-blue-700" />

          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-1 rounded-full">
            {notifications.length}
          </span>
        </div>

        <div ref={adminRef} className="relative">

          <div
            onClick={() => setOpen(!open)}
            className="flex items-center gap-2 cursor-pointer"
          >
            <FaUserCircle className="text-4xl text-blue-700" />

            <div>
              <h2 className="font-semibold">Admin</h2>
              <p className="text-sm text-gray-500">Administrator</p>
            </div>
          </div>

          {open && (
            <div className="absolute right-0 mt-3 w-72 bg-white shadow-xl rounded-lg border z-50">

              <div className="p-4 border-b">
                <h2 className="font-bold text-lg">Admin Profile</h2>
                <p className="text-sm text-gray-500">
                  administrator@zakat.com
                </p>
              </div>

              <div className="p-2 space-y-1">

                <button
                  onClick={() => navigate("/profile")}
                  className="w-full text-left hover:bg-gray-100 p-2 rounded"
                >
                  👤 View Profile
                </button>

                <button
                  onClick={() => navigate("/settings")}
                  className="w-full text-left hover:bg-gray-100 p-2 rounded"
                >
                  ⚙️ Settings
                </button>

                <button
                  onClick={() => navigate("/notifications")}
                  className="w-full text-left hover:bg-gray-100 p-2 rounded"
                >
                  🔔 Notifications
                </button>

                <button
                  onClick={handleLogout}
                  className="w-full text-left bg-red-500 text-white p-2 rounded hover:bg-red-600"
                >
                  🚪 Logout
                </button>

              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}

export default Navbar;