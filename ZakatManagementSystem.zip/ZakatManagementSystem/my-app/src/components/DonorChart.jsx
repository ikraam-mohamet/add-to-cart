import { Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend);

function DonorChart({ donors }) {

  const data = {
    labels: ["Total Donors", "Remaining Space"],
    datasets: [
      {
        data: [donors.length, 100 - donors.length],
        backgroundColor: ["#16a34a", "#e5e7eb"],
      },
    ],
  };

  return (
    <div className="w-full md:w-1/2 mx-auto">
      <Pie data={data} />
    </div>
  );
}

export default DonorChart;