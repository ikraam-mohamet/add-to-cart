function StatCard({ title, value, color }) {
  return (
    <div className="bg-white rounded-xl shadow-md p-5">

      <div className="flex items-center gap-4">

        <div className={`w-14 h-14 rounded-full ${color}`}></div>

        <div>
          <h3 className="text-gray-500 text-sm">
            {title}
          </h3>

          <p className="text-3xl font-bold">
            {value}
          </p>
        </div>

      </div>

    </div>
  );
}

export default StatCard;