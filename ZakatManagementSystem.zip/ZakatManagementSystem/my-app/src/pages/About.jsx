import React from "react";

function About() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">

      <div className="bg-white shadow-lg rounded-lg max-w-3xl p-8">

        <h1 className="text-3xl font-bold text-green-600 mb-4">
          About Zakat Management System
        </h1>

        <p className="text-gray-700 mb-4 leading-7">
          This system is designed to manage Zakat payments in a simple,
          fast, and secure way. It helps track donors, beneficiaries, and
          payment records in one place.
        </p>

        <p className="text-gray-700 mb-4 leading-7">
          The system provides features like adding payments, updating records,
          generating reports, and viewing total Zakat contributions.
        </p>

        <div className="bg-green-50 p-4 rounded border-l-4 border-green-600">
          <h2 className="font-bold text-green-700 mb-2">Key Features:</h2>
          <ul className="list-disc ml-5 text-gray-700">
            <li>Manage Donors and Beneficiaries</li>
            <li>Track Zakat Payments</li>
            <li>Generate Reports</li>
            <li>Secure Authentication System</li>
          </ul>
        </div>

        <p className="mt-6 text-sm text-gray-500">
          © 2026 Zakat Management System. All rights reserved.
        </p>

      </div>

    </div>
  );
}

export default About;