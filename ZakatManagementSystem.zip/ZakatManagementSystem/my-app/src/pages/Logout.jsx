import { useNavigate } from "react-router-dom";

const navigate = useNavigate();

<button
  onClick={() => navigate("/")}
  className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg"
>
  Logout
</button>