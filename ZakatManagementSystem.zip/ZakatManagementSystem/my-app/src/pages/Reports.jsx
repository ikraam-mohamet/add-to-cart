import React, { useEffect, useState } from "react";
import axios from "axios";

const BASE_URL = "https://localhost:7216/api/ZakatPayment";

function Reports() {
  const [payments, setPayments] = useState([]);

  // ================= LOAD DATA =================
  const loadPayments = async () => {
    try {
      const res = await axios.get(BASE_URL);
      setPayments(res.data || []);
    } catch (error) {
      console.log("REPORT ERROR:", error);
    }
  };

  useEffect(() => {
    loadPayments();
  }, []);

  // ================= TOTALS =================
  const totalAmount = payments.reduce(
    (sum, p) => sum + Number(p.amount || p.Amount || 0),
    0
  );

  const totalPayments = payments.length;

  // ================= PRINT =================
  const handlePrint = () => {
    window.print(); // clean print (NO new tab)
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">

      {/* HEADER */}
      <div className="flex justify-between items-center mb-6 print:hidden">
        <h1 className="text-2xl font-bold">📊 Zakat Report Pro</h1>

        <button
          onClick={handlePrint}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          🖨 Print Report
        </button>
      </div>

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">

        <div className="bg-white shadow p-5 rounded">
          <h2 className="text-gray-500">Total Payments</h2>
          <p className="text-3xl font-bold">{totalPayments}</p>
        </div>

        <div className="bg-white shadow p-5 rounded">
          <h2 className="text-gray-500">Total Amount</h2>
          <p className="text-3xl font-bold text-green-600">
            ${totalAmount}
          </p>
        </div>

      </div>

      {/* TABLE */}
      <div className="bg-white shadow rounded overflow-x-auto">

        <table className="w-full text-sm">

          <thead className="bg-green-600 text-white">
            <tr>
              <th className="p-3">ID</th>
              <th className="p-3">Donor</th>
              <th className="p-3">Beneficiary</th>
              <th className="p-3">Amount</th>
              <th className="p-3">Date</th>
            </tr>
          </thead>

          <tbody>
            {payments.length === 0 ? (
              <tr>
                <td colSpan="5" className="text-center p-4">
                  No data available
                </td>
              </tr>
            ) : (
              payments.map((p, i) => (
                <tr key={i} className="text-center border-b hover:bg-gray-50">

                  <td className="p-2">{p.paymentID || p.PaymentID}</td>
                  <td className="p-2">{p.donorID || p.DonorID}</td>
                  <td className="p-2">{p.beneficiaryID || p.BeneficiaryID}</td>
                  <td className="p-2 font-semibold text-green-600">
                    ${p.amount || p.Amount}
                  </td>
                  <td className="p-2">
                    {(p.paymentDate || p.PaymentDate)?.split("T")[0]}
                  </td>

                </tr>
              ))
            )}
          </tbody>

        </table>

      </div>

    </div>
  );
}

export default Reports;