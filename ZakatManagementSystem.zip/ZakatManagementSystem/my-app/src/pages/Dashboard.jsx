

import { useEffect, useState } from "react";
import { getDonors } from "../api/donorApi";
import axios from "axios";

import {
  FaUsers,
  FaHandHoldingUsd,
  FaMoneyBillWave,
  FaUserCheck,
} from "react-icons/fa";

const PAYMENT_URL = "https://localhost:7216/api/ZakatPayment";
const BENEFICIARY_URL = "https://localhost:7216/api/Beneficiary";

function Dashboard() {
  const [donors, setDonors] = useState([]);
  const [beneficiaries, setBeneficiaries] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    try {
      setLoading(true);

      const [dRes, bRes, pRes] = await Promise.all([
        getDonors(),
        axios.get(BENEFICIARY_URL),
        axios.get(PAYMENT_URL),
      ]);

      setDonors(dRes.data || []);
      setBeneficiaries(bRes.data || []);
      setPayments(pRes.data || []);
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  };

  const getAmount = (p) =>
    Number(p?.amount ?? p?.Amount ?? 0);

  const totalDonors = donors.length;
  const totalReceivers = beneficiaries.length;
  const totalCollected = payments.reduce((s, p) => s + getAmount(p), 0);
  const paymentCount = payments.length;

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center text-gray-500">
        Loading dashboard...
      </div>
    );
  }

  const Card = ({ icon, title, value, color }) => (
    <div className="bg-white border rounded-xl shadow-sm p-5 flex items-center justify-between hover:shadow-md transition">
      
      <div>
        <p className="text-gray-500 text-sm">{title}</p>
        <h2 className="text-2xl font-bold text-gray-800">{value}</h2>
      </div>

      <div className={`text-4xl ${color}`}>
        {icon}
      </div>

    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6">

      {/* HEADER */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">
          📊 Zakat Dashboard
        </h1>
        <p className="text-gray-500">
          Clean white UI with real data
        </p>
      </div>

      {/* STATS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">

        <Card
          icon={<FaUsers />}
          title="Total Donors"
          value={totalDonors}
          color="text-blue-500"
        />

        <Card
          icon={<FaUserCheck />}
          title="Beneficiaries"
          value={totalReceivers}
          color="text-green-500"
        />

        <Card
          icon={<FaHandHoldingUsd />}
          title="Collected"
          value={`$${totalCollected}`}
          color="text-purple-500"
        />

        <Card
          icon={<FaMoneyBillWave />}
          title="Payments"
          value={paymentCount}
          color="text-orange-500"
        />

      </div>

      {/* RECENT SECTION */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">

        {/* PAYMENTS */}
        <div className="bg-white border rounded-xl shadow-sm p-5">

          <h2 className="text-lg font-bold text-blue-600 mb-4">
            💰 Recent Payments
          </h2>

          <div className="space-y-3">
            {payments.slice(-5).reverse().map((p, i) => (
              <div
                key={i}
                className="flex justify-between border-b pb-2"
              >
                <span className="text-gray-700">
                  Donor #{p.donorID}
                </span>

                <span className="text-green-600 font-semibold">
                  ${getAmount(p)}
                </span>
              </div>
            ))}
          </div>

        </div>

        {/* DISTRIBUTION */}
        <div className="bg-white border rounded-xl shadow-sm p-5">

          <h2 className="text-lg font-bold text-purple-600 mb-4">
            👥 Distribution
          </h2>

          <div className="space-y-3">
            {Object.values(
              payments.reduce((acc, p) => {
                const id = p.beneficiaryID;

                if (!acc[id]) acc[id] = { id, amount: 0 };

                acc[id].amount += getAmount(p);

                return acc;
              }, {})
            ).slice(0, 5).map((d, i) => (
              <div
                key={i}
                className="flex justify-between border-b pb-2"
              >
                <span className="text-gray-700">
                  Beneficiary #{d.id}
                </span>

                <span className="text-purple-600 font-semibold">
                  ${d.amount}
                </span>
              </div>
            ))}
          </div>

        </div>

      </div>

    </div>
  );
}

export default Dashboard;