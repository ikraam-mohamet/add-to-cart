function Profile() {
  const user = localStorage.getItem("user") || "Admin";

  return (
    <div className="bg-white p-6 rounded shadow space-y-4">

      <h1 className="text-3xl font-bold">👤 Admin Profile</h1>

      <div className="space-y-2">
        <p><b>Name:</b> {user}</p>
        <p><b>Email:</b> admin@zakat.com</p>
        <p><b>Role:</b> Administrator</p>
        <p><b>Status:</b> Active</p>
      </div>

     

    </div>
  );
}

export default Profile;