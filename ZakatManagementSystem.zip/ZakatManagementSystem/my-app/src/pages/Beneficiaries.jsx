import React, { useEffect, useState } from "react";
import axios from "axios";

const BASE_URL = "https://localhost:7216/api/Beneficiary";

function Beneficiaries() {
  const [beneficiaries, setBeneficiaries] = useState([]);

  const [formOpen, setFormOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);

  const [searchName, setSearchName] = useState("");

  const [formData, setFormData] = useState({
    beneficiaryID: "",
    fullName: "",
    phone: "",
    address: "",
  });

  // ================= LOAD ALL =================
  const loadBeneficiaries = async () => {
    try {
      const res = await axios.get(BASE_URL);
      setBeneficiaries(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    loadBeneficiaries();
  }, []);

  // ================= SEARCH BY NAME =================
  const handleSearch = async () => {
    try {
      const res = await axios.get(`${BASE_URL}/search`, {
        params: { name: searchName },
      });

      if (!res.data || res.data.length === 0) {
        alert("❌ No Beneficiary found");
        return;
      }

      setBeneficiaries(res.data);
    } catch (error) {
      console.log(error);
      alert("❌ Search not found");
    }
  };

  // ================= RESET =================
  const handleReset = () => {
    setSearchName("");
    loadBeneficiaries();
  };

  // ================= ADD =================
  const handleAdd = () => {
    setFormData({
      beneficiaryID: "",
      fullName: "",
      phone: "",
      address: "",
    });

    setIsEdit(false);
    setFormOpen(true);
  };

  // ================= EDIT =================
  const handleEdit = (b) => {
    setFormData({
      beneficiaryID: b.beneficiaryID,
      fullName: b.fullName,
      phone: b.phone,
      address: b.address,
    });

    setIsEdit(true);
    setFormOpen(true);
  };

  // ================= INPUT CHANGE =================
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // ================= SAVE / UPDATE =================
  const handleSubmit = async () => {
    try {
      if (!formData.fullName || !formData.phone || !formData.address) {
        alert("❌ Please fill all fields");
        return;
      }

      if (isEdit) {
        const res = await axios.put(BASE_URL, {
          beneficiaryID: formData.beneficiaryID,
          fullName: formData.fullName,
          phone: formData.phone,
          address: formData.address,
        });

        alert(res.data || "Updated Successfully");
      } else {
        const res = await axios.post(BASE_URL, {
          fullName: formData.fullName,
          phone: formData.phone,
          address: formData.address,
        });

        alert(res.data || "Added Successfully");
      }

      setFormOpen(false);
      loadBeneficiaries();

    } catch (error) {
      console.log("ERROR:", error);

      alert(
        error?.response?.data ||
        "❌ Request failed"
      );
    }
  };

  // ================= DELETE =================
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure?")) {
      await axios.delete(`${BASE_URL}/${id}`);
      loadBeneficiaries();
    }
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">

      {/* HEADER */}
      <div className="flex justify-between mb-4">
        <h1 className="text-2xl font-bold">
          🎯 Beneficiary Management
        </h1>

        <button
          onClick={handleAdd}
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          ➕ Add Beneficiary
        </button>
      </div>

      {/* SEARCH BY NAME */}
      <div className="bg-white p-3 rounded shadow mb-4 flex gap-2">

        <input
          type="text"
          placeholder="Search by name..."
          value={searchName}
          onChange={(e) => setSearchName(e.target.value)}
          className="border p-2 rounded w-1/3"
        />

        <button
          onClick={handleSearch}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Search
        </button>

        <button
          onClick={handleReset}
          className="bg-gray-500 text-white px-4 py-2 rounded"
        >
          Reset
        </button>

      </div>

      {/* FORM */}
      {formOpen && (
        <div className="bg-white p-4 rounded shadow mb-6">

          <h2 className="font-bold mb-3">
            {isEdit ? "✏️ Update Beneficiary" : "➕ Add Beneficiary"}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">

            <input
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Full Name"
              className="border p-2 rounded"
            />

            <input
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="Phone"
              className="border p-2 rounded"
            />

            <input
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="Address"
              className="border p-2 rounded"
            />

          </div>

          <div className="flex gap-3 mt-3">

            <button
              onClick={handleSubmit}
              className="bg-blue-600 text-white px-4 py-2 rounded"
            >
              {isEdit ? "Update" : "Save"}
            </button>

            <button
              onClick={() => setFormOpen(false)}
              className="bg-gray-500 text-white px-4 py-2 rounded"
            >
              Cancel
            </button>

          </div>

        </div>
      )}

      {/* TABLE */}
      <div className="bg-white shadow rounded overflow-hidden">

        <table className="w-full text-sm">

          <thead className="bg-green-600 text-white">
            <tr>
              <th className="p-3">ID</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {beneficiaries.map((b) => (
              <tr key={b.beneficiaryID} className="border-b hover:bg-gray-50">

                <td className="p-3">{b.beneficiaryID}</td>
                <td>{b.fullName}</td>
                <td>{b.phone}</td>
                <td>{b.address}</td>

                <td className="flex gap-2 p-2">

                  <button
                    onClick={() => handleEdit(b)}
                    className="bg-yellow-500 text-white px-3 py-1 rounded"
                  >
                    Update
                  </button>

                  <button
                    onClick={() => handleDelete(b.beneficiaryID)}
                    className="bg-red-500 text-white px-3 py-1 rounded"
                  >
                    Delete
                  </button>

                </td>

              </tr>
            ))}
          </tbody>

        </table>

      </div>

    </div>
  );
}

export default Beneficiaries;