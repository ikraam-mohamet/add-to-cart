
import React, { useEffect, useState } from "react";
import {
  getDonors,
  createDonor,
  updateDonor,
  deleteDonor,
} from "../api/donorApi";

function Donor() {
  const [donors, setDonors] = useState([]);

  const [formOpen, setFormOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);

  const [formData, setFormData] = useState({
    donorID: "",
    fullName: "",
    phone: "",
    address: "",
  });

  // LOAD DATA
  const loadDonors = async () => {
    const res = await getDonors();
    setDonors(res.data);
  };

  useEffect(() => {
    loadDonors();
  }, []);

  // OPEN ADD FORM
  const handleAddClick = () => {
    setFormData({
      donorID: "",
      fullName: "",
      phone: "",
      address: "",
    });
    setIsEdit(false);
    setFormOpen(true);
  };

  // OPEN EDIT FORM
  const handleEdit = (donor) => {
    setFormData(donor);
    setIsEdit(true);
    setFormOpen(true);
  };

  // INPUT CHANGE
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // SAVE (ADD / UPDATE)
  const handleSubmit = async () => {
    if (
      !formData.fullName ||
      !formData.phone ||
      !formData.address
    ) {
      alert("Please fill all fields");
      return;
    }

    if (isEdit) {
      await updateDonor(formData);
      alert("Updated Successfully");
    } else {
      await createDonor(formData);
      alert("Added Successfully");
    }

    setFormOpen(false);
    loadDonors();
  };

  // DELETE
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure?")) {
      await deleteDonor(id);
      loadDonors();
    }
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">

      {/* TITLE + ADD BUTTON */}
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">
          💰 Donor Management
        </h1>

        <button
          onClick={handleAddClick}
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          ➕ Add Donor
        </button>
      </div>

      {/* FORM */}
      {formOpen && (
        <div className="bg-white p-4 rounded shadow mb-6">

          <h2 className="font-bold mb-3">
            {isEdit ? "✏️ Update Donor" : "➕ Add Donor"}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">

            <input
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Full Name"
              className="border p-2 rounded"
            />

            <input
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="Phone"
              className="border p-2 rounded"
            />

            <input
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="Address"
              className="border p-2 rounded"
            />

          </div>

          <div className="flex gap-3 mt-3">

            <button
              onClick={handleSubmit}
              className="bg-blue-600 text-white px-4 py-2 rounded"
            >
              {isEdit ? "Update" : "Save"}
            </button>

            <button
              onClick={() => setFormOpen(false)}
              className="bg-gray-500 text-white px-4 py-2 rounded"
            >
              Cancel
            </button>

          </div>
        </div>
      )}

      {/* TABLE */}
      <div className="bg-white shadow rounded overflow-hidden">

        <table className="w-full text-sm">

          <thead className="bg-blue-600 text-white">
            <tr>
              <th className="p-3">ID</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {donors.map((d) => (
              <tr key={d.donorID} className="border-b hover:bg-gray-50">

                <td className="p-3">{d.donorID}</td>
                <td>{d.fullName}</td>
                <td>{d.phone}</td>
                <td>{d.address}</td>

                <td className="flex gap-2 p-2">

                  <button
                    onClick={() => handleEdit(d)}
                    className="bg-yellow-500 text-white px-3 py-1 rounded"
                  >
                    Update
                  </button>

                  <button
                    onClick={() => handleDelete(d.donorID)}
                    className="bg-red-500 text-white px-3 py-1 rounded"
                  >
                    Delete
                  </button>

                </td>

              </tr>
            ))}
          </tbody>

        </table>

      </div>

    </div>
  );
}

export default Donor;