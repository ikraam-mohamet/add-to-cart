import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Login({ setIsAuth }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await axios.get("https://localhost:7216/api/Users");

      const users = res.data || [];

      const user = users.find(
        (u) =>
          (u.username || u.Username) === username &&
          (u.password || u.Password) === password
      );

      if (!user) {
        setError("❌ Invalid username or password");
        setLoading(false);
        return;
      }

      localStorage.setItem("user", JSON.stringify(user));
      localStorage.setItem("auth", "true");

      setIsAuth(true);
      navigate("/dashboard");

    } catch (err) {
      console.log("LOGIN ERROR:", err);

      if (err.code === "ERR_NETWORK") {
        setError("❌ Backend not running or wrong URL");
      } else {
        setError("❌ Server error");
      }

    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">

      <form
        onSubmit={handleLogin}
        className="bg-white p-6 rounded shadow w-96"
      >

        <h2 className="text-2xl font-bold mb-4">Login</h2>

        <input
          type="text"
          className="w-full p-2 border mb-3"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          className="w-full p-2 border mb-3"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {error && (
          <p className="text-red-500 mb-2">{error}</p>
        )}

        <button
          type="submit"
          className="bg-green-600 text-white w-full py-2 rounded"
          disabled={loading}
        >
          {loading ? "Logging in..." : "Login"}
        </button>

      </form>

    </div>
  );
}

export default Login;