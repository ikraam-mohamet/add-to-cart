import { useEffect } from "react";

function Settings({
  darkMode,
  setDarkMode,
  notifications,
  setNotifications,
}) {
  // Load saved settings
  useEffect(() => {
    const savedDark = localStorage.getItem("darkMode") === "true";
    const savedNotif = localStorage.getItem("notifications") === "true";

    setDarkMode(savedDark);
    setNotifications(savedNotif);
  }, []);

  const saveSettings = () => {
    localStorage.setItem("darkMode", darkMode);
    localStorage.setItem("notifications", notifications);

    alert("Settings Saved ✅");
  };

  return (
    <div className={`min-h-screen p-6 ${darkMode ? "bg-black text-white" : "bg-gray-100 text-black"}`}>

      <h1 className="text-3xl font-bold mb-6">
        ⚙️ Settings
      </h1>

      <div className={`p-6 rounded-xl shadow-lg ${darkMode ? "bg-gray-900" : "bg-white"}`}>

        {/* DARK MODE */}
        <div className="flex items-center justify-between border-b pb-4 mb-4">
          <span className="font-semibold">🌙 Dark Mode</span>

          <input
            type="checkbox"
            checked={darkMode}
            onChange={(e) => setDarkMode(e.target.checked)}
            className="w-5 h-5"
          />
        </div>

        {/* NOTIFICATIONS */}
        <div className="flex items-center justify-between border-b pb-4 mb-6">
          <span className="font-semibold">🔔 Notifications</span>

          <input
            type="checkbox"
            checked={notifications}
            onChange={(e) => setNotifications(e.target.checked)}
            className="w-5 h-5"
          />
        </div>

        {/* SAVE BUTTON */}
        <button
          onClick={saveSettings}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-bold transition"
        >
          Save Settings
        </button>

      </div>
    </div>
  );
}

export default Settings;