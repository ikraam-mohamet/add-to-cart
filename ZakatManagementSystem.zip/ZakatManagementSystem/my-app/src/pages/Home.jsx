

import React, { useState } from "react";
import {
  FaMosque,
  FaDonate,
  FaUsers,
  FaHandsHelping,
} from "react-icons/fa";

function Home() {
  const [openFAQ, setOpenFAQ] = useState(null);

  const toggleFAQ = (index) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };

  return (
    <div className="bg-gray-50 font-sans">

      {/* ================= NAVBAR ================= */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center h-20">

          <div className="flex items-center gap-2">
            <FaMosque className="text-green-600" size={28} />
            <h1 className="text-2xl font-bold text-green-700">ZakatCare</h1>
          </div>

          <div className="hidden md:flex gap-6 text-gray-700 font-medium">
            <a href="#home" className="hover:text-green-600">Home</a>
            <a href="#programs" className="hover:text-green-600">Programs</a>
            <a href="#about" className="hover:text-green-600">About</a>
          </div>

          <a
            href="/login"
            className="bg-green-600 hover:bg-green-700 transition text-white px-4 py-2 rounded-lg"
          >
            Login
          </a>

        </div>
      </nav>

      {/* ================= HERO ================= */}
      <section id="home" className="bg-gradient-to-r from-green-700 to-green-900 text-white py-24">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">

          <div>
            <h1 className="text-5xl font-bold leading-tight">
              Give Zakat, Change Lives ❤️
            </h1>

            <p className="mt-5 text-lg text-gray-100">
              Help families access food, education, and healthcare through your Zakat.
            </p>

            <div className="mt-6 flex gap-4">
              <button className="bg-yellow-400 hover:bg-yellow-300 text-black px-6 py-3 rounded-lg font-semibold">
                Donate Now
              </button>
            </div>
          </div>

          <img
            className="rounded-2xl shadow-2xl"
            src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c"
            alt=""
          />
        </div>
      </section>

      {/* ================= STATS ================= */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-4 gap-6 text-center">

          <div>
            <FaDonate size={40} className="mx-auto text-green-600" />
            <h2 className="text-3xl font-bold">$500K+</h2>
            <p>Zakat Collected</p>
          </div>

          <div>
            <FaUsers size={40} className="mx-auto text-green-600" />
            <h2 className="text-3xl font-bold">10K+</h2>
            <p>Beneficiaries</p>
          </div>

          <div>
            <FaHandsHelping size={40} className="mx-auto text-green-600" />
            <h2 className="text-3xl font-bold">1K+</h2>
            <p>Volunteers</p>
          </div>

          <div>
            <FaMosque size={40} className="mx-auto text-green-600" />
            <h2 className="text-3xl font-bold">50+</h2>
            <p>Communities</p>
          </div>

        </div>
      </section>

      {/* ================= ABOUT ================= */}
      <section id="about" className="py-20 bg-gray-100">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-10 items-center">

          <img
            className="rounded-xl shadow-lg"
            src="https://images.unsplash.com/photo-1469571486292-b53601020f1f"
            alt=""
          />

          <div>
            <h2 className="text-4xl font-bold text-green-700">
              About Our Mission
            </h2>

            <p className="mt-4 text-gray-600">
              We ensure your Zakat reaches real needy families with full transparency and trust.
            </p>
          </div>

        </div>
      </section>

      {/* ================= PROGRAMS ================= */}
      <section id="programs" className="py-20 bg-white text-center">
        <h2 className="text-4xl font-bold text-green-700">Our Programs</h2>

        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-8 mt-10">

          <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:scale-105 transition">
            <img src="https://images.unsplash.com/photo-1547592180-85f173990554" className="h-48 w-full object-cover" />
            <div className="p-5">
              <h3 className="text-xl font-bold text-green-700">Food Support</h3>
              <p className="text-gray-600 mt-2">Helping families with meals.</p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:scale-105 transition">
            <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7" className="h-48 w-full object-cover" />
            <div className="p-5">
              <h3 className="text-xl font-bold text-green-700">Education</h3>
              <p className="text-gray-600 mt-2">Supporting children education.</p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:scale-105 transition">
            <img src="https://images.unsplash.com/photo-1584515933487-779824d29309" className="h-48 w-full object-cover" />
            <div className="p-5">
              <h3 className="text-xl font-bold text-green-700">Healthcare</h3>
              <p className="text-gray-600 mt-2">Medical support for needy.</p>
            </div>
          </div>

        </div>
      </section>

      {/* ================= FAQ ================= */}
      <section className="py-20 bg-gray-100">
        <div className="max-w-3xl mx-auto px-6">

          <h2 className="text-4xl font-bold text-center text-green-700">FAQ</h2>

          <div className="mt-8 space-y-4">

            {[
              {
                q: "What is Zakat?",
                a: "Zakat is an Islamic obligation of giving wealth to the poor.",
              },
              {
                q: "Where does donation go?",
                a: "It goes directly to verified families.",
              },
              {
                q: "Is it safe?",
                a: "Yes, fully tracked and transparent.",
              },
            ].map((item, i) => (
              <div key={i} className="bg-white p-4 rounded shadow cursor-pointer">
                <div onClick={() => toggleFAQ(i)} className="font-semibold">
                  {item.q}
                </div>

                {openFAQ === i && (
                  <p className="mt-2 text-gray-600">{item.a}</p>
                )}
              </div>
            ))}

          </div>
        </div>
      </section>

      {/* ================= FOOTER ================= */}
      <footer className="bg-green-700 text-white py-10 text-center">
        <h2 className="text-2xl font-bold">ZakatCare</h2>
        <p>Helping people through Zakat</p>
        <p className="mt-4">© 2026 All Rights Reserved</p>
      </footer>

    </div>
  );
}

export default Home;