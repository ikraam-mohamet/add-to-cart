import React, { useEffect, useState } from "react";
import axios from "axios";

const BASE_URL = "https://localhost:7216/api/ZakatPayment";

function Payment() {
  const [payments, setPayments] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);

  const [formData, setFormData] = useState({
    paymentID: 0,
    donorID: "",
    beneficiaryID: "",
    amount: "",
    paymentDate: "",
  });

  // ================= LOAD =================
  const loadPayments = async () => {
    try {
      const res = await axios.get(BASE_URL);
      setPayments(res.data || []);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    loadPayments();
  }, []);

  // ================= ADD =================
  const handleAdd = () => {
    setFormData({
      paymentID: 0,
      donorID: "",
      beneficiaryID: "",
      amount: "",
      paymentDate: "",
    });
    setIsEdit(false);
    setFormOpen(true);
  };

  // ================= EDIT =================
  const handleEdit = (p) => {
    setFormData({
      paymentID: p.paymentID,
      donorID: p.donorID,
      beneficiaryID: p.beneficiaryID,
      amount: p.amount,
      paymentDate: p.paymentDate?.split("T")[0],
    });
    setIsEdit(true);
    setFormOpen(true);
  };

  // ================= CHANGE =================
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // ================= SAVE =================
  const handleSave = async () => {
    try {
      const payload = {
        donorID: Number(formData.donorID),
        beneficiaryID: Number(formData.beneficiaryID),
        amount: Number(formData.amount),
        paymentDate: new Date(formData.paymentDate).toISOString(),
      };

      const res = await axios.post(BASE_URL, payload);

      alert(res.data);

      setFormOpen(false);
      loadPayments();
    } catch (error) {
      console.log(error);
      alert(error.response?.data || "❌ Add failed");
    }
  };

  // ================= UPDATE (🔥 FIXED HERE) =================
  const handleUpdate = async () => {
    try {
      const payload = {
        paymentID: Number(formData.paymentID),
        donorID: Number(formData.donorID),
        beneficiaryID: Number(formData.beneficiaryID),
        amount: Number(formData.amount),
        paymentDate: new Date(formData.paymentDate).toISOString(),
      };

      // 🔥 IMPORTANT FIX: ID in URL
      const res = await axios.put(
        `${BASE_URL}/${formData.paymentID}`,
        payload
      );

      alert(res.data);

      setFormOpen(false);
      loadPayments();
    } catch (error) {
      console.log(error);
      alert(error.response?.data || "❌ Update failed");
    }
  };

  // ================= DELETE =================
  const handleDelete = async (id) => {
    try {
      if (window.confirm("Are you sure?")) {
        await axios.delete(`${BASE_URL}/${id}`);
        loadPayments();
      }
    } catch (error) {
      console.log(error);
      alert("❌ Delete failed");
    }
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">

      {/* HEADER */}
      <div className="flex justify-between mb-4">
        <h1 className="text-2xl font-bold">💰 Zakat Payment</h1>

        <button
          onClick={handleAdd}
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          ➕ Add Payment
        </button>
      </div>

      {/* FORM */}
      {formOpen && (
        <div className="bg-white p-4 rounded shadow mb-4">

          <input
            name="donorID"
            value={formData.donorID}
            onChange={handleChange}
            placeholder="Donor ID"
            className="border p-2 m-1"
          />

          <input
            name="beneficiaryID"
            value={formData.beneficiaryID}
            onChange={handleChange}
            placeholder="Beneficiary ID"
            className="border p-2 m-1"
          />

          <input
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            placeholder="Amount"
            className="border p-2 m-1"
          />

          <input
            type="date"
            name="paymentDate"
            value={formData.paymentDate}
            onChange={handleChange}
            className="border p-2 m-1"
          />

          <div className="mt-3">
            <button
              onClick={isEdit ? handleUpdate : handleSave}
              className="bg-blue-600 text-white px-4 py-2 mr-2"
            >
              {isEdit ? "Update" : "Save"}
            </button>

            <button
              onClick={() => setFormOpen(false)}
              className="bg-gray-500 text-white px-4 py-2"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* TABLE */}
      <div className="bg-white shadow rounded">
        <table className="w-full text-sm">
          <thead className="bg-blue-600 text-white">
            <tr>
              <th>ID</th>
              <th>Donor</th>
              <th>Beneficiary</th>
              <th>Amount</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {payments.map((p) => (
              <tr key={p.paymentID} className="text-center border-b">

                <td>{p.paymentID}</td>
                <td>{p.donorID}</td>
                <td>{p.beneficiaryID}</td>
                <td>{p.amount}</td>
                <td>{p.paymentDate?.split("T")[0]}</td>

                <td className="space-x-2">
                  <button
                    onClick={() => handleEdit(p)}
                    className="bg-yellow-500 px-3 py-1 text-white rounded"
                  >
                    Edit
                  </button>

                  <button
                    onClick={() => handleDelete(p.paymentID)}
                    className="bg-red-500 px-3 py-1 text-white rounded"
                  >
                    Delete
                  </button>
                </td>

              </tr>
            ))}
          </tbody>
        </table>
      </div>

    </div>
  );
}

export default Payment;