import { useState } from "react";

function Notification() {
  const [notifications, setNotifications] = useState([
    "New donation received 💰",
    "New user registered 👤",
    "System report ready 📊",
    "Monthly zakat report generated 📄",
  ]);

  const clearAll = () => setNotifications([]);

  return (
    <div className="bg-white p-6 rounded shadow">

      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold">🔔 Notifications</h1>

        <button
          onClick={clearAll}
          className="bg-red-500 text-white px-3 py-1 rounded"
        >
          Clear All
        </button>
      </div>

      {notifications.length === 0 ? (
        <p className="text-gray-500">No notifications</p>
      ) : (
        notifications.map((n, i) => (
          <div
            key={i}
            className="p-3 border-b hover:bg-gray-100"
          >
            {n}
          </div>
        ))
      )}

    </div>
  );
}

export default Notification;