
import axios from "axios";

const BASE_URL = "https://localhost:7216/api/ZakatPayment";

// ================= GET ALL PAYMENTS =================
export const getPayments = async () => {
  return await axios.get(BASE_URL);
};

// ================= GET PAYMENT BY ID =================
export const getPaymentById = async (id) => {
  return await axios.get(`${BASE_URL}/${id}`);
};

// ================= CREATE PAYMENT =================
export const createPayment = async (data) => {
  return await axios.post(BASE_URL, {
    donorID: Number(data.donorID),
    beneficiaryID: Number(data.beneficiaryID),
    amount: Number(data.amount),
    paymentDate: data.paymentDate,
  });
};

// ================= UPDATE PAYMENT (FIXED - IMPORTANT) =================
export const updatePayment = async (data) => {
  if (!data.paymentID) {
    throw new Error("paymentID is missing ❌");
  }

  return await axios.put(
    `${BASE_URL}/${data.paymentID}`, // 🔥 IMPORTANT FIX
    {
      paymentID: Number(data.paymentID),
      donorID: Number(data.donorID),
      beneficiaryID: Number(data.beneficiaryID),
      amount: Number(data.amount),
      paymentDate: data.paymentDate,
    }
  );
};

// ================= DELETE PAYMENT =================
export const deletePayment = async (id) => {
  return await axios.delete(`${BASE_URL}/${id}`);
};