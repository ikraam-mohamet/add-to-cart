
import axios from "axios";

const BASE_URL = "https://localhost:7216/api/Beneficiary";

// ================= GET ALL =================
export const getBeneficiaries = () => {
  return axios.get(BASE_URL);
};

// ================= CREATE =================
export const createBeneficiary = (data) => {
  return axios.post(BASE_URL, {
    fullName: data.fullName,
    phone: data.phone,
    address: data.address,
  });
};

// ================= UPDATE (MATCHES YOUR BACKEND) =================
export const updateBeneficiary = (data) => {
  return axios.put(BASE_URL, {
    beneficiaryID: data.beneficiaryID,
    fullName: data.fullName,
    phone: data.phone,
    address: data.address,
  });
};

// ================= DELETE =================
export const deleteBeneficiary = (id) => {
  return axios.delete(`${BASE_URL}/${id}`);
};

// ================= SEARCH BY NAME =================
export const searchBeneficiary = (name) => {
  return axios.get(`${BASE_URL}/search`, {
    params: { name },
  });
};