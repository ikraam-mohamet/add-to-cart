
import axios from "axios";

const API = "https://localhost:7216/api/Donor";

// GET ALL
export const getDonors = () => {
  return axios.get(API);
};

// CREATE
export const createDonor = (data) => {
  return axios.post(API, {
    fullName: data.fullName,
    phone: data.phone,
    address: data.address,
  });
};

// UPDATE
export const updateDonor = (data) => {
  return axios.put(API, {
    donorID: data.donorID,
    fullName: data.fullName,
    phone: data.phone,
    address: data.address,
  });
};

// DELETE
export const deleteDonor = (id) => {
  return axios.delete(`${API}/${id}`);
};